//
//  GPYPaymentOptionsMetadata.h
//  GopayCheckoutSDK
//
//  Created by Muhammad.Masykur on 11/05/20.
//  Copyright © 2020 Gojek. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface GPYPaymentOptionsMetadata : NSObject

@end

NS_ASSUME_NONNULL_END

